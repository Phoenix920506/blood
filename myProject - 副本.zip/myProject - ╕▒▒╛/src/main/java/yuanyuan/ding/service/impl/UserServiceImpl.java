package yuanyuan.ding.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import yuanyuan.ding.bean.Tuser;
import yuanyuan.ding.logging.LogColumnName;
import yuanyuan.ding.mapper.UserMapper;
import yuanyuan.ding.service.UserService;

import javax.annotation.Resource;
@Service
public class UserServiceImpl implements UserService {
@Resource
@Autowired
private UserMapper userMapper;
    @Override
    public Tuser getUserByuserno(String userno) {
        return userMapper.getUserByUserifno(userno);
    }

    @Override
    public int updateUserByid(String userno, String mobile, String address) {
//        System.out.println(id+tel+address);
        return userMapper.updateUserByid(userno,mobile,address);
    }
    @Override
    public  int alterpassword(String userno,String password){
        return userMapper.alterpassword(userno,password);
    }
//    public  int adduser(String userno,String password,String username,String sex,Integer age,String IDnumber,String mobile,String address){
//        //return userMapper.adduser(userno,password,username,sex,age,IDnumber,mobile,address);
//        return userMapper.adduser()
//    }
    @Override
    public  int adduser(Tuser tuser){
        //return userMapper.adduser(userno,password,username,sex,age,IDnumber,mobile,address);
        return userMapper.adduser(tuser);
    }
    @Override
    public int alteruser(Tuser tuser){
        return userMapper.alteruser(tuser);
    }
    @Override
    public int deleteuser(Tuser tuser){
        return userMapper.deleteuser(tuser);
   }

    @Override
    public int updateLoging(String id) {
        return userMapper.updateLogging(id);
    }
//    @Override
//    public LogColumnName getRole(String  role) {
//        return userMapper.getRole(role);
//    }
    @Override
    public int updateLogingState(String id,String state){
        return  userMapper.updateLoggingState(id,state);
    }

    @Override
    public int deleteFromLog(String userno) {
        return userMapper.deleteFromLog(userno);
    }
    @Override
    public String selectIDformLog(String num){
        return userMapper.getUserLoggingId(num);
    }
}
