package yuanyuan.ding.service;

import yuanyuan.ding.bean.Tuser;
import yuanyuan.ding.logging.LogColumnName;

public interface UserService {
    Tuser getUserByuserno(String userno);
    //LogColumnName getRole(String role);
    int updateUserByid(String id,String tel,String address);
    int alterpassword(String userno,String password);
    //int adduser(String userno,String password,String username,String sex,Integer age,String IDnumber,String mobile,String address);
    int adduser(Tuser tuser);
    int alteruser(Tuser tuser);
    int deleteuser(Tuser tuser);
    int updateLoging(String id);
    int updateLogingState(String id,String state);
    int deleteFromLog(String userno);
    String selectIDformLog(String num);
}
