package yuanyuan.ding.mapper;

import org.apache.ibatis.annotations.*;
import yuanyuan.ding.bean.Tuser;
import yuanyuan.ding.logging.LogColumnName;

@Mapper
public interface UserMapper {
    @Select("select * from tuser where userno=#{userno}")
    public Tuser getUserByUserifno(String userno);

    @Select("select * from log where exists(select userno=#{userno} from tuser where (log.userno=#{userno})=(tuser.userno=#{userno}))")
    public LogColumnName getRole(String  role);

    @Update("update tuser set mobile=#{mobile}, address=#{address} where userno=#{userno}")
    public int updateUserByid(@Param("userno")String userno,@Param("mobile") String mobile,@Param("address") String address);

    @Update("update tuser set password=#{password} where userno=#{userno}")
    public  int alterpassword(@Param("userno")String userno,@Param("password")String password);

//    @Insert("insert into tuser values(userno=#{userno},password=#{password},username=#{username},sex=#{sex},age=#{age},IDnumber=#{IDnumber},#mobile={mobile},address=#{address})")
//    public int adduser(@Param("userno")String userno,@Param("password")String password,@Param("username")String username,@Param("sex")String sex,@Param("age")Integer age,@Param("IDnumber")String IDnumber,@Param("mobile")String mobile,@Param("address")String address);

    @Update("update tuser set password=#{password},username=#{username},sex=#{sex},age=#{age},IDnumber=#{idnumber},mobile=#{mobile},address=#{address} where userno=#{userno}")
    public int alteruser(Tuser tuser);

    @Insert("insert into tuser set userno=#{userno},password=#{password},username=#{username},sex=#{sex},age=#{age},IDnumber=#{idnumber},mobile=#{mobile},address=#{address}")
    public int adduser(Tuser tuser);

    @Delete("delete from tuser where userno=#{userno}")
    public int deleteuser(Tuser tuser);
    @Update("update userlogin set id=#{userno}")
    public int updateLogging(String userno);
    @Update("update userlogin set id=#{userno},state=#{state}")
    public int updateLoggingState(@Param("userno") String userno,@Param("state") String state);
    @Select("select id from userlogin where num=#{num}")
    public String getUserLoggingId(String num);
    @Delete("delete from log where role=#{userno}")
    public int deleteFromLog(String userno);
}
