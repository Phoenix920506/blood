package yuanyuan.ding.controller;

import com.alibaba.druid.util.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import yuanyuan.ding.Response.CommonReturnType;
import yuanyuan.ding.bean.Tuser;
import yuanyuan.ding.error.BusinessException;
import yuanyuan.ding.error.EmBusinessError;
import yuanyuan.ding.mapper.UserMapper;
import yuanyuan.ding.service.UserService;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.HashMap;

@RestController
@SessionAttributes
public class UserController {
    @Resource
    @Autowired
    private UserService userService;
    @Resource
    @Autowired
    private UserMapper userMapper;
    private HttpSession httpSession;

//
//    @Autowired
//    private userpasswordDO userpasswordDO;
    @Resource
    @Autowired
    private HttpServletRequest httpServletRequest;

    @GetMapping("/select")
    public String get(){
        return "fasaga";
    }
    @GetMapping("/login")
    public CommonReturnType getUser(@RequestParam(name = "userno")String userno,@RequestParam(name = "password")String password) throws BusinessException {
        System.out.println(userno+password);
//        HashMap<String,String> operation = new HashMap<>();
//        operation.put("登录","login");
//        operation.put("删除","delete");
//        httpServletRequest.getSession().setAttribute("operation",operation);
//        this.httpServletRequest.getSession().setAttribute("id",userno);
//        String id = (String) httpServletRequest.getSession().getAttribute("id");
//        System.out.println("当前登录的是"+id);
//        System.out.println(httpServletRequest.getSession().getAttribute("operation"));
        userService.updateLogingState(userno,"no");
        if (StringUtils.isEmpty(userno)|| StringUtils.isEmpty(password)){
           userService.deleteFromLog(userno);
            throw new BusinessException(EmBusinessError.PARAMETER_VALIDATION_ERROR);
        }

        //System.out.println(userno+password);
        Tuser user = userService.getUserByuserno(userno);
        if(user==null){
            userService.deleteFromLog(userno);
            return CommonReturnType.create(null,"用户不存在");
//            throw new BusinessException(EmBusinessError.UNKNOWN_ERROR);
        }else{
            if (!StringUtils.equals(password,user.getPassword())){
                //throw new BusinessException(EmBusinessError.USER_PASSWORD_ERROR);
                userService.deleteFromLog(userno);
                return CommonReturnType.create(null,"密码或用户名错误");
            }else{
                this.httpServletRequest.getSession().setAttribute("IS_LOGIN",true);
                this.httpServletRequest.getSession().setAttribute("LOGIN_USER",user);
                userService.updateLogingState(userno,"yes");
                System.out.println(userMapper.getUserLoggingId("1"));
                return CommonReturnType.create(user);
            }
        }
    }


    @GetMapping("/updateUser")
    public CommonReturnType updateUserById (@RequestParam(name = "id")String id,
                                  @RequestParam(name = "tel")String tel,@RequestParam(name = "address")String address) throws BusinessException {
//
//        System.out.println(id + tel + address);
        int update = userService.updateUserByid(id, tel, address);
        if (update == 0) {
            return CommonReturnType.create(false, "fail");
        } else {
            return CommonReturnType.create(true, "success");
        }
    }
     @GetMapping("/alterPassword")
        public CommonReturnType alterpassword(@RequestParam(name = "userno")String userno, @RequestParam(name = "password")String password) throws BusinessException{

            System.out.println(userno+password);
            int alter = userService.alterpassword(userno,password);
            if(alter==0){
                return CommonReturnType.create(false,"fail");
            }else{
                return CommonReturnType.create(true,"success");
            }
    }

    @GetMapping("/addUser")
    public CommonReturnType adduser(Tuser tuser) throws BusinessException{
        int adduser = userService.adduser(tuser);
        //int alteruser = userService.adduser(userno,password,username,sex,age,IDnumber,mobile,address);
        if(adduser==0){
            return CommonReturnType.create(false,"fail");
        }else{
            return CommonReturnType.create(true,"success");
        }
    }
    @GetMapping("/alterUser")
    public CommonReturnType alteruser(Tuser tuser) throws BusinessException{
        int alteruser = userService.alteruser(tuser);
        //int alteruser = userService.adduser(userno,password,username,sex,age,IDnumber,mobile,address);
        if(alteruser==0){
            return CommonReturnType.create(false,"fail");
        }else{
            return CommonReturnType.create(true,"success");
        }
    }
    @GetMapping("/deleteUser")
    public CommonReturnType deleteuser(Tuser tuser) throws BusinessException{
        int deleteuser = userService.deleteuser(tuser);
        //int alteruser = userService.adduser(userno,password,username,sex,age,IDnumber,mobile,address);
        if(deleteuser==0){
            return CommonReturnType.create(false,"fail");
        }else{
            return CommonReturnType.create(true,"success");
        }
    }



}
