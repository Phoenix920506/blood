package yuanyuan.ding.logging;

public enum LogTableName {
	log
}
