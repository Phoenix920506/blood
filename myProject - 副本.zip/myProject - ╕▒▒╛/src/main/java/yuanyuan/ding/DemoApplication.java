package yuanyuan.ding;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import javax.servlet.http.HttpServletRequest;
import java.util.ArrayList;
import java.util.HashMap;

@SpringBootApplication
public class DemoApplication {
   // private HttpServletRequest httpServletRequest;
    public static void main(String[] args) {
       // DemoApplication demoApplication = new DemoApplication();
        SpringApplication.run(DemoApplication.class, args);
    }

}
