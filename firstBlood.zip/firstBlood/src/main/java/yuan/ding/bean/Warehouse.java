package yuan.ding.bean;

public class Warehouse {
    private Integer warehouseId;

    private String warehousePlace;

    private Integer warehouseNumber;

    private Integer cabinetNumber;

    private Integer layerNumber;

    private String warehouseTemper;

    public Integer getWarehouseId() {
        return warehouseId;
    }

    public void setWarehouseId(Integer warehouseId) {
        this.warehouseId = warehouseId;
    }

    public String getWarehousePlace() {
        return warehousePlace;
    }

    public void setWarehousePlace(String warehousePlace) {
        this.warehousePlace = warehousePlace == null ? null : warehousePlace.trim();
    }

    public Integer getWarehouseNumber() {
        return warehouseNumber;
    }

    public void setWarehouseNumber(Integer warehouseNumber) {
        this.warehouseNumber = warehouseNumber;
    }

    public Integer getCabinetNumber() {
        return cabinetNumber;
    }

    public void setCabinetNumber(Integer cabinetNumber) {
        this.cabinetNumber = cabinetNumber;
    }

    public Integer getLayerNumber() {
        return layerNumber;
    }

    public void setLayerNumber(Integer layerNumber) {
        this.layerNumber = layerNumber;
    }

    public String getWarehouseTemper() {
        return warehouseTemper;
    }

    public void setWarehouseTemper(String warehouseTemper) {
        this.warehouseTemper = warehouseTemper == null ? null : warehouseTemper.trim();
    }

    public Warehouse(){}
    public Warehouse(Integer warehouseNumber, Integer cabinetNumber,Integer layerNumber){
        this.warehouseNumber = warehouseNumber;
        this.cabinetNumber = cabinetNumber;
        this.layerNumber = layerNumber;
    }
}
