package yuan.ding.bean;

import java.util.Date;

public class InsertDaily {

    private Date dailyDate;

    private String dailyName;

    private String dailyPhonenumber;

    private String dailyPerformance;

    private String exceptioncheck;

    private String dailyRecord;

    public Date getDailyDate() {
        return dailyDate;
    }

    public void setDailyDate(Date dailyDate) {
        this.dailyDate = dailyDate;
    }

    public String getDailyName() {
        return dailyName;
    }

    public void setDailyName(String dailyName) {
        this.dailyName = dailyName == null ? null : dailyName.trim();
    }

    public String getDailyPhonenumber() {
        return dailyPhonenumber;
    }

    public void setDailyPhonenumber(String dailyPhonenumber) {
        this.dailyPhonenumber = dailyPhonenumber;
    }

    public String getDailyPerformance() {
        return dailyPerformance;
    }

    public void setDailyPerformance(String dailyPerformance) {
        this.dailyPerformance = dailyPerformance == null ? null : dailyPerformance.trim();
    }

    public String getExceptioncheck() {
        return exceptioncheck;
    }

    public void setExceptioncheck(String exceptioncheck) {
        this.exceptioncheck = exceptioncheck == null ? null : exceptioncheck.trim();
    }

    public String getDailyRecord() {
        return dailyRecord;
    }

    public void setDailyRecord(String dailyRecord) {
        this.dailyRecord = dailyRecord == null ? null : dailyRecord.trim();
    }
}
