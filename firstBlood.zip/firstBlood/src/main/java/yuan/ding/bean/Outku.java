package yuan.ding.bean;

import java.util.Date;

public class Outku {
    private String patientid;//病历号

    private String patientname;

    //private String hName;

    private String blotype;//血型

    private String blokind;//血液品种

    private Integer transamount;//输血量

    private Date transdate;//输血日期

    private String getbloman;

    private String postbloman;

    public String getPatientid() {
        return patientid;
    }

    public void setPatientid(String patientid) {
        this.patientid = patientid;
    }

    public String getPatientname() {
        return patientname;
    }

    public void setPatientname(String patientname) {
        this.patientname = patientname;
    }

//    public String gethName() {
//        return hName;
//    }
//
//    public void sethName(String hName) {
//        this.hName = hName;
//    }

    public String getBlotype() {
        return blotype;
    }

    public void setBlotype(String blotype) {
        this.blotype = blotype;
    }

    public String getBlokind() {
        return blokind;
    }

    public void setBlokind(String blokind) {
        this.blokind = blokind;
    }

    public Integer getTransamount() {
        return transamount;
    }

    public void setTransamount(Integer transamount) {
        this.transamount = transamount;
    }

    public Date getTransdate() {
        return transdate;
    }

    public void setTransdate(Date transdate) {
        this.transdate = transdate;
    }

    public String getGetbloman() {
        return getbloman;
    }

    public void setGetbloman(String getbloman) {
        this.getbloman = getbloman;
    }

    public String getPostbloman() {
        return postbloman;
    }

    public void setPostbloman(String postbloman) {
        this.postbloman = postbloman;
    }
}
