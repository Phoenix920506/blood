package yuan.ding.bean;

import java.util.Date;

public class Inku {

    private Integer bloid;

    public Integer getBloid() {
        return bloid;
    }

    public void setBloid(Integer bloid) {
        this.bloid = bloid;
    }

    private String offeridnumber;

    private String offerbloman;

    private String blotype;

    private Integer blovolume;

    private String blokind;

    private String getbloman;

    private Date indate;

    private int warehouseId;

    public int getWarehouseId() {
        return warehouseId;
    }

    public void setWarehouseId(int warehouseId) {
        this.warehouseId = warehouseId;
    }

    public String getOfferidnumber() {
        return offeridnumber;
    }

    public void setOfferidnumber(String offeridnumber) {
        this.offeridnumber = offeridnumber;
    }

    public String getOfferbloman() {
        return offerbloman;
    }

    public void setOfferbloman(String offerbloman) {
        this.offerbloman = offerbloman;
    }

    public String getBlotype() {
        return blotype;
    }

    public void setBlotype(String blotype) {
        this.blotype = blotype;
    }

    public Integer getBlovolume() {
        return blovolume;
    }

    public void setBlovolume(Integer blovolume) {
        this.blovolume = blovolume;
    }

    public String getBlokind() {
        return blokind;
    }

    public void setBlokind(String blokind) {
        this.blokind = blokind;
    }

    public String getGetbloman() {
        return getbloman;
    }

    public void setGetbloman(String getbloman) {
        this.getbloman = getbloman;
    }

    public Date getIndate() {
        return indate;
    }

    public void setIndate(Date indate) {
        this.indate = indate;
    }

    public Inku(){

    }

    public Inku( String offeridnumber, String offerbloman, String blotype, Integer blovolume, String blokind, String getbloman, Date indate, int warehouseId) {

        this.offeridnumber = offeridnumber;
        this.offerbloman = offerbloman;
        this.blotype = blotype;
        this.blovolume = blovolume;
        this.blokind = blokind;
        this.getbloman = getbloman;
        this.indate = indate;
        this.warehouseId = warehouseId;
    }
}
