package yuan.ding.bean;

import java.util.Date;

public class Ventory {
    private String bloType;
    private String bloKind;
//    private Date indate;
    private int capacity;
    private String warehouse;
//    private int warehouse_number;
//    private int cabinet_number;
//    private int layer_number;
    private String username;

    public String getBloType() {
        return bloType;
    }

    public void setBloType(String bloType) {
        this.bloType = bloType;
    }

    public String getBloKind() {
        return bloKind;
    }

    public void setBloKind(String bloKind) {
        this.bloKind = bloKind;
    }

//    public Date getIndate() {
//        return indate;
//    }
//
//    public void setIndate(Date indate) {
//        this.indate = indate;
//    }

    public int getCapacity() {
        return capacity;
    }

    public void setCapacity(int capacity) {
        this.capacity = capacity;
    }

//    public int getWarehouse_number() {
//        return warehouse_number;
//    }
//
//    public void setWarehouse_number(int warehouse_number) {
//        this.warehouse_number = warehouse_number;
//    }
//
//    public int getCabinet_number() {
//        return cabinet_number;
//    }
//
//    public void setCabinet_number(int cabinet_number) {
//        this.cabinet_number = cabinet_number;
//    }
//
//    public int getLayer_number() {
//        return layer_number;
//    }
//
//    public void setLayer_number(int layer_number) {
//        this.layer_number = layer_number;
//    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getWarehouse() {
        return warehouse;
    }

    public void setWarehouse(String warehouse) {
        this.warehouse = warehouse;
    }
}
