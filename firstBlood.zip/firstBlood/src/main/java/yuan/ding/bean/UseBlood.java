package yuan.ding.bean;

import java.io.Serializable;
import java.util.Date;

public class UseBlood  implements Serializable {
    private String h_Name;

    private String patientname;

    private String sex;

    private Integer age;

    private String p_tel;

    private String patientid;

    private String blotype;

    private String blokind;

    private Integer transamount;

    private String username;

    private Date transdate;

    public UseBlood(){}

    public String gethName() {
        return h_Name;
    }

    public Date getTransdate() {
        return transdate;
    }

    public void setTransdate(Date transdate) {
        this.transdate = transdate;
    }

    public String getUsername() {

        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public Integer getTransamount() {

        return transamount;
    }

    public void setTransamount(Integer transamount) {
        this.transamount = transamount;
    }

    public String getBlokind() {

        return blokind;
    }

    public void setBlokind(String blokind) {
        this.blokind = blokind;
    }

    public String getBlotype() {

        return blotype;
    }

    public void setBlotype(String blotype) {
        this.blotype = blotype;
    }

    public String getPatientid() {

        return patientid;
    }

    public void setPatientid(String patientid) {
        this.patientid = patientid;
    }

    public String getPtel() {

        return p_tel;
    }

    public void setPtel(String ptel) {
        this.p_tel = ptel;
    }

    public void sethName(String hName) {
        this.h_Name = hName;

    }

    public Integer getAge() {
        return age;
    }

    public void setAge(Integer age) {
        this.age = age;
    }

    public String getSex() {

        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public String getPatientname() {

        return patientname;
    }

    public void setPatientname(String patientname) {
        this.patientname = patientname;
    }
}
