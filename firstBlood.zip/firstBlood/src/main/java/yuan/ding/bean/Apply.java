package yuan.ding.bean;


import java.util.Date;

public class Apply {
    private String company;
    private String county;
    private String h_name;
    private String patientID;
    private String patientName;
    private String sex;
    private Date birthday;
    private int age;
    private String p_tel;
    private Date applyDate;
    private Date bookDate;
    private String diagnous;
    private String goal;
    private String history;
    private String badHistory;
    private String pregnancy;
    private String  bloType;
    private int transAmount;
    private String bloKind;
    private String patientResult;

    public Apply() {
    }

    public Apply(String company, String county, String h_name, String patientID, String patientName, String sex, Date birthday, int age, String p_tel, Date applyDate, Date bookDate, String diagnous, String goal, String history, String badHistory, String pregnancy, String bloType, int transAmount, String bloKind, String patientResult) {
        this.company = company;
        this.county = county;
        this.h_name = h_name;
        this.patientID = patientID;
        this.patientName = patientName;
        this.sex = sex;
        this.birthday = birthday;
        this.age = age;
        this.p_tel = p_tel;
        this.applyDate = applyDate;
        this.bookDate = bookDate;
        this.diagnous = diagnous;
        this.goal = goal;
        this.history = history;
        this.badHistory = badHistory;
        this.pregnancy = pregnancy;
        this.bloType = bloType;
        this.transAmount = transAmount;
        this.bloKind = bloKind;
        this.patientResult = patientResult;
    }

    public String getCompany() {
        return company;
    }

    public void setCompany(String company) {
        this.company = company;
    }

    public String getCounty() {
        return county;
    }

    public void setCounty(String county) {
        this.county = county;
    }

    public String getH_name() {
        return h_name;
    }

    public void setH_name(String h_name) {
        this.h_name = h_name;
    }

    public String getPatientID() {
        return patientID;
    }

    public void setPatientID(String patientID) {
        this.patientID = patientID;
    }

    public String getPatientName() {
        return patientName;
    }

    public void setPatientName(String patientName) {
        this.patientName = patientName;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public Date getBirthday() {
        return birthday;
    }

    public void setBirthday(Date birthday) {
        this.birthday = birthday;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getP_tel() {
        return p_tel;
    }

    public void setP_tel(String p_tel) {
        this.p_tel = p_tel;
    }

    public Date getApplyDate() {
        return applyDate;
    }

    public void setApplyDate(Date applyDate) {
        this.applyDate = applyDate;
    }

    public Date getBookDate() {
        return bookDate;
    }

    public void setBookDate(Date bookDate) {
        this.bookDate = bookDate;
    }

    public String getDiagnous() {
        return diagnous;
    }

    public void setDiagnous(String diagnous) {
        this.diagnous = diagnous;
    }

    public String getGoal() {
        return goal;
    }

    public void setGoal(String goal) {
        this.goal = goal;
    }

    public String getHistory() {
        return history;
    }

    public void setHistory(String history) {
        this.history = history;
    }

    public String getBadHistory() {
        return badHistory;
    }

    public void setBadHistory(String badHistory) {
        this.badHistory = badHistory;
    }

    public String getPregnancy() {
        return pregnancy;
    }

    public void setPregnancy(String pregnancy) {
        this.pregnancy = pregnancy;
    }

    public String getBloType() {
        return bloType;
    }

    public void setBloType(String bloType) {
        this.bloType = bloType;
    }

    public int getTransAmount() {
        return transAmount;
    }

    public void setTransAmount(int transAmount) {
        this.transAmount = transAmount;
    }

    public String getBloKind() {
        return bloKind;
    }

    public void setBloKind(String bloKind) {
        this.bloKind = bloKind;
    }

    public String getPatientResult() {
        return patientResult;
    }

    public void setPatientResult(String patientResult) {
        this.patientResult = patientResult;
    }

}
