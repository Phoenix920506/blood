package yuan.ding.bean;

import java.util.Date;

public class Dailyrecord {

//    private Integer dailyId;

    private Date daily_date;

    private String daily_name;

    private String daily_phonenumber;

    private String daily_performance;

    private String exceptionCheck;

//    private String dailyRecord;
//
//    public Integer getDailyId() {
//        return dailyId;
//    }
//
//    public void setDailyId(Integer dailyId) {
//        this.dailyId = dailyId;
//    }

    public Date getDailyDate() {
        return daily_date;
    }

    public void setDailyDate(Date dailyDate) {
        this.daily_date = dailyDate;
    }

    public String getDailyName() {
        return daily_name;
    }

    public void setDailyName(String dailyName) {
        this.daily_name = dailyName == null ? null : dailyName.trim();
    }

    public String getDailyPhonenumber() {
        return daily_phonenumber;
    }

    public void setDailyPhonenumber(String dailyPhonenumber) {
        this.daily_phonenumber = dailyPhonenumber;
    }

    public String getDailyPerformance() {
        return daily_performance;
    }

    public void setDailyPerformance(String dailyPerformance) {
        this.daily_performance = dailyPerformance == null ? null : dailyPerformance.trim();
    }

    public String getExceptioncheck() {
        return exceptionCheck;
    }

    public void setExceptioncheck(String exceptioncheck) {
        this.exceptionCheck = exceptioncheck == null ? null : exceptioncheck.trim();
    }

//    public String getDailyRecord() {
//        return dailyRecord;
//    }
//
//    public void setDailyRecord(String dailyRecord) {
//        this.dailyRecord = dailyRecord == null ? null : dailyRecord.trim();
//    }
}