package yuan.ding.bean;

import java.util.Date;

public class Bloodinstorage {

    private Date indate;

    private String blokind;//血液品种

    private String blotype;//血型

    private String getbloman;

    private Date effectivedate;

    private Integer blovolume;//血量

    private String offerbloman;

    private String offeridnumber;

    private Integer warehouseId;


    public Date getIndate() {
        return indate;
    }

    public void setIndate(Date indate) {
        this.indate = indate;
    }

    public String getBlokind() {
        return blokind;
    }

    public void setBlokind(String blokind) {
        this.blokind = blokind == null ? null : blokind.trim();
    }

    public String getBlotype() {
        return blotype;
    }

    public void setBlotype(String blotype) {
        this.blotype = blotype == null ? null : blotype.trim();
    }

    public String getGetbloman() {
        return getbloman;
    }

    public void setGetbloman(String getbloman) {
        this.getbloman = getbloman == null ? null : getbloman.trim();
    }

    public Date getEffectivedate() {
        return effectivedate;
    }

    public void setEffectivedate(Date effectivedate) {
        this.effectivedate = effectivedate;
    }

    public Integer getBlovolume() {
        return blovolume;
    }

    public void setBlovolume(Integer blovolume) {
        this.blovolume = blovolume;
    }

    public String getOfferbloman() {
        return offerbloman;
    }

    public void setOfferbloman(String offerbloman) {
        this.offerbloman = offerbloman == null ? null : offerbloman.trim();
    }

    public String getOfferidnumber() {
        return offeridnumber;
    }

    public void setOfferidnumber(String offeridnumber) {
        this.offeridnumber = offeridnumber == null ? null : offeridnumber.trim();
    }

    public Integer getWarehouseId() {
        return warehouseId;
    }

    public void setWarehouseId(Integer warehouseId) {
        this.warehouseId = warehouseId;
    }


}
