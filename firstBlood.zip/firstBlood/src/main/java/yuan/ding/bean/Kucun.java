package yuan.ding.bean;

import java.util.Date;

public class Kucun {
    private Date indate;    //入库日期

    private String blokind;//血液品种

    private String blotype;//血型

    private Integer capacity;//库存量

    private String getbloman;//采血人

    private String warehouseTemper;//温度

    private Integer warehouseNumber;//库

    private Integer cabinetNumber;//柜

    private Integer layerNumber;//层

    private Date effectivedate;//有效日期

    private String offeridnumber;//供血者编号

    public Kucun() {
    }

    public Kucun(Date indate, String blokind, String blotype, Integer capacity, String getbloman, String warehouseTemper, Integer warehouseNumber, Integer cabinetNumber, Integer layerNumber, Date effectivedate, String offeridnumber) {
        this.indate = indate;
        this.blokind = blokind;
        this.blotype = blotype;
        this.capacity = capacity;
        this.getbloman = getbloman;
        this.warehouseTemper = warehouseTemper;
        this.warehouseNumber = warehouseNumber;
        this.cabinetNumber = cabinetNumber;
        this.layerNumber = layerNumber;
        this.effectivedate = effectivedate;
        this.offeridnumber = offeridnumber;
    }

    public Integer getCabinetNumber() {
        return cabinetNumber;
    }

    public void setCabinetNumber(Integer cabinetNumber) {
        this.cabinetNumber = cabinetNumber;
    }

    public Date getIndate() {
        return indate;
    }

    public void setIndate(Date indate) {
        this.indate = indate;
    }

    public String getBlokind() {
        return blokind;
    }

    public void setBlokind(String blokind) {
        this.blokind = blokind;
    }

    public String getBlotype() {
        return blotype;
    }

    public void setBlotype(String blotype) {
        this.blotype = blotype;
    }

    public Integer getCapacity() {
        return capacity;
    }

    public void setCapacity(Integer capacity) {
        this.capacity = capacity;
    }

    public String getGetbloman() {
        return getbloman;
    }

    public void setGetbloman(String getbloman) {
        this.getbloman = getbloman;
    }

    public String getWarehouseTemper() {
        return warehouseTemper;
    }

    public void setWarehouseTemper(String warehouseTemper) {
        this.warehouseTemper = warehouseTemper;
    }

    public Integer getWarehouseNumber() {
        return warehouseNumber;
    }

    public void setWarehouseNumber(Integer warehouseNumber) {
        this.warehouseNumber = warehouseNumber;
    }

    public Integer getLayerNumber() {
        return layerNumber;
    }

    public void setLayerNumber(Integer layerNumber) {
        this.layerNumber = layerNumber;
    }

    public Date getEffectivedate() {
        return effectivedate;
    }

    public void setEffectivedate(Date effectivedate) {
        this.effectivedate = effectivedate;
    }

    public String getOfferidnumber() {
        return offeridnumber;
    }

    public void setOfferidnumber(String offeridnumber) {
        this.offeridnumber = offeridnumber;
    }
}
