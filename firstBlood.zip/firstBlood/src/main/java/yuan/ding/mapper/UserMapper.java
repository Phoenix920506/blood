package yuan.ding.mapper;

import org.apache.ibatis.annotations.*;
import org.springframework.web.bind.annotation.PathVariable;
import yuan.ding.bean.*;
import yuan.ding.logging.LogColumnName;

import javax.annotation.security.PermitAll;
import java.util.Date;
import java.util.List;

@Mapper
public interface UserMapper {

    User loadUserByUsername(String username);

    List<Role> getRolesByUserId(Long id);

    int userReg(@Param("username") String username, @Param("password") String password);

    List<User> getUsersByKeywords(@Param("keywords") String keywords);

    int updateHr(User user);

    int deleteRoleByHrId(Long userId);

    int addRolesForHr(@Param("userId") Long hrId, @Param("rids") Long[] rids);

    User getHrById(Long userId);

    int deleteHr(Long userId);

    List<User> getAllHr(@Param("currentId") Long currentId);

    //登录
    @Select("select * from tuser where userno=#{userno}")
    User getUserByUserifno(@PathVariable("userno") String userno);

    //库存管理
    //按血型查询
    @Select("select * from bloodinstorage where bloType=#{blotype}")
    Bloodinstorage findByBloType(@Param("blotype") String blotype,@Param("a") Integer a, @Param("line") Integer line);

    //按品种查询
    @Select("select * from bloodinstorage where bloKind=#{blokind}")
    Bloodinstorage findByBloKind(@Param("blokind") String blokind,@Param("a") Integer a, @Param("line") Integer line);

    //库存管理页面查显示 入库日期 血型 品种instorage 库存量inventory   采血人instorage     温度   存放位置 warehouse 有效日期   供血者编号instorage
//    @Select("select inDate,bloodinstorage.bloType,bloodinstorage.bloKind,capacity,getBloman,warehouse_temper," +
//            "warehouse_number,cabinet_number,layer_number,effectiveDate,offerIDnumber from bloodinstorage,bloodinventory," +
//            "warehouse where bloodinstorage.bloType = bloodinventory.bloType and bloodinventory.warehouse_id = warehouse.warehouse_id")

    @Select("select * from bloodinstorage,bloodinventory," +
            "warehouse where bloodinstorage.bloType = bloodinventory.bloType and bloodinventory.warehouse_id = warehouse.warehouse_id")
    List<Kucun> findAllwarehouse(@Param("a") Integer a, @Param("line") Integer line);

    //插入入库单
    @Insert("insert into bloodinstorage(offerIDnumber,offerBloman,bloType,bloVolume,bloKind,getBloman,inDate,warehouse_id)" +
            "values(#{offeridnumber},#{offerbloman},#{blotype},#{blovolume},#{blokind},#{getbloman},#{indate},#{warehouseId})")
    void insertKu(@Param("offeridnumber")String offeridnumber, @Param("offerbloman")String offerbloman, @Param("blotype")String blotype,@Param("blovolume")Integer blovolume,@Param("blokind")String blokind,@Param("getbloman")String getbloman,@Param("indate")Date indate,@Param("warehouseId") int warehouseId);

    //入库帐
    //按储血号查询
    @Select("select * from bloodinstorage where bloId=#{bloid}")
    Bloodinstorage findByBloId(@Param("bloid") Integer bloid,@Param("a") Integer a, @Param("line") Integer line);

    //按供血者姓名
    @Select("select * from bloodinstorage where offerBloman=#{offerbloman}")
    Bloodinstorage findByOfferBloMan(@Param("offerbloman") String offerbloman, @Param("a") Integer a, @Param("line") Integer line);

    //入库帐页面显示 储血号 供血者编号 供血者姓名  血型      血量       品种   采血人   入库日期=采血日期 bloodinstorage
    @Select("select bloId,offerIDnumber,offerBloman,bloType,bloVolume,bloKind,getBloman,inDate from bloodinstorage")
    List<Inku> findInstorage(@Param("a") Integer a, @Param("line") Integer line);

    //查询出库单的病历号 病人姓名 判断p_count
    @Select("select p_count from patient where patientID=#{patientid},patientName=#{patientname}")
    int selectpcount(@Param("patientid") String patientid,@Param("patientname") String patientname);

    //根据拼p_count判断 插入出库单
    @Insert("insert into bloodoutstorage(bloType,bloKind,transAmount,transDate,getBloman,postBloman,getBloman,inDate) values(#{blotype},#{blokind},#{getbloman},#{transamount},#{transdate},#{getbloman},#{postbloman}) where p_count = #{pcount}")
    void outKu(@Param("blotype")String blotype,@Param("blokind")String blokind,@Param("transamount") Integer transamount,@Param("transdate")Date transdate,@Param("getbloman") String getbloman,@Param("postbloman")String postbloman);

    //出库帐
    //按病历号查询
    @Select("select * from patient where patientID=#{patientid}")
    Patient findByPatientId(@Param("patientid") String patientid,@Param("a") Integer a, @Param("line") Integer line);

    //按病人姓名查询
    @Select("select * from patient where patientName=#{patientname} limit 10")
    Patient findByPatientName(@Param("patientname") String patientname,@Param("a") Integer a, @Param("line") Integer line);


    //出库帐页面显示 病历号 病人姓名patient 血型 品种instorage 输血量 输血日期 采血人 发血人outstorage
    @Select("select patientID,patientName,bloodinstorage.bloType,bloodinstorage.bloKind,bloodoutstorage.transAmount," +
            "transDate,bloodinstorage.getBloman,postBloman from bloodinstorage,patient,bloodoutstorage " +
            "where patient.bloType = bloodinstorage.bloType and bloodinstorage.bloType = bloodoutstorage.bloType")
    List<Outku> findOutstorage(@Param("a") Integer a, @Param("line") Integer line);


    //个人信息
    @Select("select * from log where exists(select userno=#{userno} from user where (log.userno=#{userno})=(user.userno=#{userno}))")
    public LogColumnName getRole(String  role);

    @Update("update user set mobile=#{mobile}, address=#{address} where userno=#{userno}")
    public int updateUserByid(@Param("userno")String userno,@Param("mobile") String mobile,@Param("address") String address);

    @Update("update user set password=#{password} where userno=#{userno}")
    public  int alterpassword(@Param("userno")String userno,@Param("password")String password);

    @Update("update user set password=#{password},username=#{username},sex=#{sex},age=#{age},IDnumber=#{idnumber},mobile=#{mobile},address=#{address} where userno=#{userno}")
    public int alteruser(User tuser);

    @Insert("insert into user set userno=#{userno},password=#{password},username=#{username},sex=#{sex},age=#{age},IDnumber=#{idnumber},mobile=#{mobile},address=#{address}")
    public int adduser(User tuser);

    @Delete("delete from user where userno=#{userno}")
    public int deleteuser(User tuser);

    @Update("update user_login set id=#{userno}")
    public int updateLogging(String userno);

    @Update("update user_login set id=#{userno},state=#{state}")
    public int updateLoggingState(@Param("userno") String userno,@Param("state") String state);

    @Select("select id from user_login where num=#{num}")
    public String getUserLoggingId(String num);

    @Delete("delete from log where role=#{userno}")
    public int deleteFromLog(String userno);
    @Update("update log set state=#{state} where date=#{date1} or date=#{date2}")
    public int updateLoggingStateByTime(@Param("state") String state,@Param("date1") String date1,@Param("date2") String date2);
    @Select("select date from log where role=#{id})")
    public String[] getTimeById(String id);
    @Delete("delete from log where state={state}")
    public int deleteByState(@Param("state") String state);
    @Update("update log set role=#{id} where date=#{date1} or date=#{date2}")
    public int updateLoggingIdByTime(@Param("id") String id,@Param("date1") String date1,@Param("date2") String date2);
}
