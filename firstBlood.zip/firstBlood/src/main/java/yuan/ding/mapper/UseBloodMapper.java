package yuan.ding.mapper;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.springframework.data.jpa.repository.Query;
import yuan.ding.bean.UseBlood;

import java.util.Date;
import java.util.List;
import java.util.Map;

@Mapper
public interface UseBloodMapper {
    //插入用血申请单，判断医院
    @Select("SELECT office_id FROM hospitalservices WHERE company=#{company} and county=#{county} and h_name=#{h_name}")
    int selectoffice_id(@Param("company") String company,@Param("county") String county,@Param("h_name") String h_name);

    //用血申请单，插入Patient表
    @Insert("INSERT INTO patient(patientID,patientName,office_id,sex,birthday,age,p_tel,applyDate,bookDate,diagnous,goal,history,badHistory,pregnancy,bloType,transAmount,bloKind,patientResult) VALUES(#{patientID},#{patientName},#{office_id},#{sex},#{birthday},#{age},#{p_tel},#{applyDate},#{bookDate},#{diagnous},#{goal},#{history},#{badHistory},#{pregnancy},#{bloType},#{transAmount},#{bloKind},#{patientResult})")
    void insertpatient(@Param("patientID")String patientID,@Param("patientName") String patientName,@Param("office_id") int office_id,@Param("sex") String sex,@Param("birthday") Date birthday,@Param("age") int age,@Param("p_tel") String p_tel,@Param("applyDate") Date applyDate,@Param("bookDate") Date bookDate,@Param("diagnous") String diagnous,@Param("goal") String goal,@Param("history") String history,@Param("badHistory") String badHistory,@Param("pregnancy") String pregnancy,@Param("bloType") String bloType,@Param("transAmount") int transAmount,@Param("bloKind") String bloKind,@Param("patientResult") String patientResult);

    //查询病人用血情况表all
    @Select("select h_name,patientName,patient.sex,patient.age,p_tel,patientID,bloodoutstorage.bloType,bloodoutstorage.bloKind,bloodoutstorage.transAmount,username,transDate " +
            "from hospitalservices,patient,bloodoutstorage,user " +
            "where patient.office_id = hospitalservices.office_id and bloodoutstorage.postBloman = user.userno;")
    List<UseBlood> selectapplyBloodQuery();

    //根据病人名字查询病人用血情况表
    @Select("select h_name,patientName,patient.sex,patient.age,p_tel,patientID,bloodoutstorage.bloType,bloodoutstorage.bloKind,bloodoutstorage.transAmount,username,transDate " +
            "from hospitalservices,patient,bloodoutstorage,user " +
            "where patient.office_id = hospitalservices.office_id and bloodoutstorage.postBloman = user.userno AND patientName = #{patientName};")
    List<UseBlood> selectapplyBloodQueryByName(String patientname);
    //根据病历号查询病人用血情况表
    @Select("select h_name,patientName,patient.sex,patient.age,p_tel,patientID,bloodoutstorage.bloType,bloodoutstorage.bloKind,bloodoutstorage.transAmount,username,transDate " +
            "from hospitalservices,patient,bloodoutstorage,user " +
            "where patient.office_id = hospitalservices.office_id and bloodoutstorage.postBloman = user.userno AND patientID = #{patientID};")
    List<UseBlood> selectapplyBloodQueryByID(String patientID);
}
