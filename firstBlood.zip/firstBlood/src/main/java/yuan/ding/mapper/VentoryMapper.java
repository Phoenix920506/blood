package yuan.ding.mapper;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import yuan.ding.bean.Bloodinventory;
import yuan.ding.bean.Ventory;

import java.util.List;

@Mapper
public interface VentoryMapper {
//    @Select("SELECT bloType,bloKind,indate,capacity,warehouse.warehouse_number,warehouse.cabinet_number,warehouse.layer_number,tuser.username " +
    @Select("SELECT bloType,bloKind,capacity,CONCAT(warehouse.warehouse_number,'库-',warehouse.cabinet_number,'柜-',warehouse.layer_number,'层') warehouse,user.username " +
        "FROM bloodinventory,warehouse,user " +
            "WHERE bloodinventory.warehouse_id = warehouse.warehouse_id AND bloodinventory.userno = user.userno AND bloType = #{bloType};")
    List<Ventory> selectVentoryByType(String bloType);

//    @Select("SELECT bloType,bloKind,indate,capacity,warehouse.warehouse_number,warehouse.cabinet_number,warehouse.layer_number,tuser.username " +
    @Select("SELECT bloType,bloKind,capacity,CONCAT(warehouse.warehouse_number,'库-',warehouse.cabinet_number,'柜-',warehouse.layer_number,'层') warehouse,user.username " +
            "FROM bloodinventory,warehouse,user " +
            "WHERE bloodinventory.warehouse_id = warehouse.warehouse_id AND bloodinventory.userno = user.userno AND bloKind = #{bloKind};")
    List<Ventory> selectVentoryByKind(String bloKind);

//    @Select("SELECT bloType,bloKind,capacity,CONCAT(warehouse.warehouse_number,'库-',warehouse.cabinet_number,'柜-',warehouse.layer_number,'层') warehouse,user.username " +
//            "FROM bloodinventory,warehouse,user " +
//            "WHERE bloodinventory.warehouse_id = warehouse.warehouse_id AND bloodinventory.userno = user.userno AND indate = #{indate};")
//    List<Ventory> selectVentoryByDate(String indate);

    @Select("SELECT bloType,bloKind,capacity,CONCAT(warehouse.warehouse_number,'库-',warehouse.cabinet_number,'柜-',warehouse.layer_number,'层') warehouse,user.username " +
            "FROM bloodinventory,warehouse,user " +
            "WHERE bloodinventory.warehouse_id = warehouse.warehouse_id AND bloodinventory.userno = user.userno;")
    List<Ventory> selectVentory();
}
