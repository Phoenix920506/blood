package yuan.ding.mapper;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Service;
import yuan.ding.bean.Dailyrecord;
import yuan.ding.bean.InsertDaily;

import java.util.Date;
import java.util.List;

@Mapper
public interface DailyMapper {
    @Select("SELECT daily_date,daily_name,daily_phonenumber,daily_performance,exceptionCheck FROM dailyrecord")
    List<Dailyrecord> selectAllDaily();

    @Insert("insert into dailyrecord(daily_date,daily_name,daily_phonenumber,daily_performance,exceptionCheck,daily_record) value(#{dailyDate},#{dailyName},#{dailyPhone},#{dailyPerformance},#{exceptioncheck},#{dailyRecord})")
    void insertdaily(@Param("dailyDate") Date dailyDate,@Param("dailyName") String dailyName,@Param("dailyPhone") String dailyPhone,@Param("dailyPerformance") String dailyPerformance,@Param("exceptioncheck") String exceptioncheck,@Param("dailyRecord") String dailyRecord);

}
