package yuan.ding.logging;

public enum LogTableName {
	log
}
