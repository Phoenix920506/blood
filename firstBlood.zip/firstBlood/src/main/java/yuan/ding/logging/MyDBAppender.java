package yuan.ding.logging;

import ch.qos.logback.classic.db.DBAppender;
import ch.qos.logback.classic.spi.ILoggingEvent;
import com.sun.org.apache.xerces.internal.util.SymbolTable;
import com.sun.org.apache.xerces.internal.util.SynchronizedSymbolTable;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.SessionAttributes;
import yuan.ding.bean.User;
import yuan.ding.mapper.UserMapper;
import yuan.ding.service.UserService;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.sql.DataSource;
import java.lang.reflect.Method;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;
@SessionAttributes
public class MyDBAppender extends DBAppender {

	final static Logger log = LoggerFactory.getLogger(MyDBAppender.class);
	@Resource
	@Autowired
    private UserMapper userMapper;
	@Resource
	@Autowired
	private UserService userService;
	protected String insertPropertiesSQL; 
	protected String insertExceptionSQL; 
	protected String insertSQL; 
	protected static final Method GET_GENERATED_KEYS_METHOD;
	String url = "jdbc:mysql://localhost:3306/pong?serverTimezone=GMT";
	private MyDBNameResolver dbNameResolver;
	private Connection conn;
	private Date d;
	private String method;
	private String sql;
	private String o_way;
	//private String ip;
	private SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd kk:mm:ss ");
	@Resource
	@Autowired
//	private HttpServletRequest httpServletRequest;
//	private HttpSession httpSession;
	private User user;
	private String e_id;
	@Autowired
	DataSource dataSource;

	public Connection getConnection() throws SQLException {
		if(dataSource!=null)
			return	dataSource.getConnection();
		return getConnectionSource().getConnection();
	}


	static { 
		Method getGeneratedKeysMethod; 
		try { 
			getGeneratedKeysMethod = PreparedStatement.class.getMethod("getGeneratedKeys", (Class[]) null); 
		} catch (Exception ex) { 
			getGeneratedKeysMethod = null; 
		} 
		GET_GENERATED_KEYS_METHOD = getGeneratedKeysMethod; 
	} 


	public MyDBAppender(){}
	public MyDBNameResolver getDbNameResolver() {
		return dbNameResolver;
	}
	public void setDbNameResolver(MyDBNameResolver dbNameResolver) {
		this.dbNameResolver = dbNameResolver;
	}

	@Override 
	public void start() {

		super.start();
		if (dbNameResolver == null) 
			dbNameResolver = new MyDBNameResolver();
		insertSQL = MySQLBuilder.buildInsertSQL(dbNameResolver);
		System.out.println("insertSQL"+insertSQL);
	}

	@Override 
	protected void subAppend(ILoggingEvent event, Connection connection, PreparedStatement insertStatement) throws Throwable { 

			bindLoggingEventWithInsertStatement(insertStatement, event);
			int updateCount = -1;
			//System.out.println(event.getFormattedMessage());
			if(event.getThreadName().contains("RMI TCP Connection"))
			{
				String i[] = event.getThreadName().split("-");
				//ip = i[1];
			}
			if(event.getFormattedMessage().contains("GET")||event.getFormattedMessage().contains("POST")||event.getFormattedMessage().contains("Preparing")){
			if(event.getFormattedMessage().contains("GET")||event.getFormattedMessage().contains("POST")){
				method = event.getFormattedMessage();
			}else{
				sql = event.getFormattedMessage();
                o_way=event.getLoggerName();//取方法名
			}
			if((method.contains("GET")||method.contains("POST"))&&sql.contains("Preparing")){
				try {
					conn=DriverManager.getConnection(url, "root", "root");
					if(conn!=null)
					{
						PreparedStatement ps = null;

						String sqlQuery = "select id from user_login";
						ps=conn.prepareStatement(sqlQuery);//处理从userlogin临时存储的id值
						ResultSet rs = ps.executeQuery();
						int col = rs.getMetaData().getColumnCount();
						while (rs.next()) {
							for (int i = 1; i <= col; i++) {
								e_id = rs.getString(i);
							}
						}
						d=new Date();//输出系统自带时间
						System.out.println("格式化输出：" + sdf.format(d));
						PreparedStatement stmt=conn.prepareStatement(insertSQL);
                        String c_way = "";
						String request = "";
						System.out.println(method);
						String s3[] = method.split("/");
						String s4[] = s3[1].split("'");
						request="/"+s4[0];
						String r_way = "";
						//String parms = "";
						//String o_way = "";
						String o_sql="";
						String date = "";
						date = sdf.format(d);
						System.out.println("开始打印日志");
						String log = event.getFormattedMessage();
						if(method.contains("GET")||method.contains("POST")){
							String s1[]=method.split(",");
							if(method.contains("GET")){
								r_way="GET"; //request_way处理请求
							}else{
								r_way="POST";
							}
						}
						if(sql.contains("Preparing")){
							String s[] = sql.split(":");
							o_sql =  s[1];//取：右边字符串
						}
						//返回的方法用到.的情况
						if(o_way.contains(".")){//取方法的名字（用分割）
						    o_way = o_way.replace(".",",");
						    String s2[]=o_way.split(",");
						    o_way = s2[s2.length-1];
                        }
						String id="1";
						stmt.setString(1, e_id);
						//stmt.setString(2, c_way);
						stmt.setString(2, request);
						stmt.setString(3, r_way);
						//stmt.setString(5, parms);
						stmt.setString(4,o_way);
						//
						stmt.setString(5,date);
						stmt.setString(6,o_sql);
						stmt.setString(7,"false");
						stmt.executeUpdate();
						conn.close();
						method="";
						sql="";
					}
				} catch (Exception e) {
					log.error(" ERROR   ");
					e.printStackTrace();
				}
				if (updateCount != 1) {
					//log.error(" ERROR  IT IS ");
					//addWarn("Failed to insert loggingEvent");
				}
			}
		}
		
	}
	private boolean checkForAudit(ILoggingEvent event) {
		String logdata = event.getFormattedMessage();
		if(logdata.contains("AUDIT#")) {
			return true;
		}
		return false;
	}


	protected void secondarySubAppend(ILoggingEvent event, 
			Connection connection, long eventId) throws Throwable { 
	} 

	private void bindLoggingEventWithInsertStatement(PreparedStatement stmt, ILoggingEvent event) throws SQLException { 
		String logdata = event.getFormattedMessage();
		log.debug(" logdata   = "+ logdata);	

		parseLogData(logdata.substring(logdata.indexOf("#")+1), stmt);
	} 

	private void parseLogData(String logdata, PreparedStatement stmt) throws SQLException {
		//ILoggingEvent event;
		String requestid = null;
		String submission_date = null;
		String eID = null;
		String status = null;
		String service = null;
		String authnContextClassRef = null;
		String ipaddresss = null;

		try {
				stmt.setString(1, "111");
				stmt.setString(2, "222");
				stmt.setString(3, "333");
				stmt.setString(4, "444");
				stmt.setString(5, "555");
				stmt.setString(6, "666");

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			requestid = null;
			submission_date = null;
			eID = null;
			status = null;
			service = null;
			authnContextClassRef = null;
			ipaddresss = null;

		}

	}



	@Override 
	protected Method getGeneratedKeysMethod() { 
		return GET_GENERATED_KEYS_METHOD; 
	} 

	@Override 
	protected String getInsertSQL() { 
		return insertSQL; 
	} 

	protected void insertProperties(Map<String, String> mergedMap, 
			Connection connection, long eventId) throws SQLException {

	} 

}
