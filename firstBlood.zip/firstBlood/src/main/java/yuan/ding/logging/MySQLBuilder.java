package yuan.ding.logging;

public class MySQLBuilder {

	static String buildInsertSQL(MyDBNameResolver dbNameResolver) {
		StringBuilder sqlBuilder = new StringBuilder("INSERT INTO ");
		sqlBuilder.append(dbNameResolver.getTableName(LogTableName.log)).append(" (");
		sqlBuilder.append(dbNameResolver.getColumnName(LogColumnName.role)).append(", ");
		sqlBuilder.append(dbNameResolver.getColumnName(LogColumnName.operation)).append(", ");
		sqlBuilder.append(dbNameResolver.getColumnName(LogColumnName.request)).append(", ");
		sqlBuilder.append(dbNameResolver.getColumnName(LogColumnName.request_way)).append(", ");
		sqlBuilder.append(dbNameResolver.getColumnName(LogColumnName.parms)).append(", ");
		sqlBuilder.append(dbNameResolver.getColumnName(LogColumnName.o_way)).append(", ");
		sqlBuilder.append(dbNameResolver.getColumnName(LogColumnName.o_sql)).append(", ");
		sqlBuilder.append(dbNameResolver.getColumnName(LogColumnName.date)).append(") ");
		sqlBuilder.append("VALUES (?,?,?,?,?,?,?,?)");
		return sqlBuilder.toString();
	}


}
