package yuan.ding.logging;

public enum LogColumnName {
//	public String getRole() {
//		return role;
//	}
//
//	public void setRole(String role) {
//		this.role = role;
//	}
	 role,
	 operation,
	 request,
	 request_way,
	 parms,
	 o_way,
	 o_sql,
	 date,

}
