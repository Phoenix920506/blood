package yuan.ding.service;

import yuan.ding.bean.Dailyrecord;
import yuan.ding.bean.InsertDaily;

import java.util.List;

public interface DailyService {
    List<Dailyrecord> selectAllDaily();

    void insertdaily(InsertDaily insertDaily);
}
