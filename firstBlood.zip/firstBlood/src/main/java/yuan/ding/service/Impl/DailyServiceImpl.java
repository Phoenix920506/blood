package yuan.ding.service.Impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import yuan.ding.bean.Dailyrecord;
import yuan.ding.bean.InsertDaily;
import yuan.ding.mapper.DailyMapper;
import yuan.ding.service.DailyService;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;

@Service
public class DailyServiceImpl implements DailyService {
    @Resource
    @Autowired
    private DailyMapper dailyMapper;

    @Override
    public List<Dailyrecord> selectAllDaily(){
        return dailyMapper.selectAllDaily();
    }

    @Override
    public void insertdaily(InsertDaily insertDaily) {
        Date dailyDate = insertDaily.getDailyDate();
        String dailyName = insertDaily.getDailyName();
        String dailyPhone = insertDaily.getDailyPhonenumber();
        String dailyPerformance = insertDaily.getDailyPerformance();
        String exceptioncheck = insertDaily.getExceptioncheck();
        String dailyRecord = insertDaily.getDailyRecord();
        System.out.println("insertdailyimpl");
        System.out.println(dailyDate+ "" +dailyName+" "+dailyPhone+ " "+dailyPerformance+" "+exceptioncheck+" "+dailyRecord);
        dailyMapper.insertdaily(dailyDate,dailyName,dailyPhone,dailyPerformance,exceptioncheck,dailyRecord);
    }
}
