package yuan.ding.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import yuan.ding.bean.*;
import yuan.ding.mapper.UserMapper;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;
import java.util.Vector;

public interface UserService {
    //登录
    User getUserByuserno(String userno);

    //库存管理
    //按血型查询
    Bloodinstorage findByBloType(String blotype,Integer a,Integer line);

    //按品种查询
    Bloodinstorage findByBloKind(String blokind,Integer a,Integer line);

    //库存管理页面查询
    List<Kucun> findAllwarehouse(Integer a,Integer line);

    //插入入库单
    void insertKu(Inku inKu);

    //入库帐
    //按储血号查询
    Bloodinstorage findByBloId(Integer bloid,Integer a,Integer line);

    //按供血者姓名
    Bloodinstorage findByOfferBloMan(String offerbloman,Integer a,Integer line);

    //入库帐页面显示
    List<Inku> findInstorage(Integer a, Integer line);

    //插入出库单
    void insertoutKu(Outku outku);
    //int selectpcount
    //void outKu

    //出库帐
    //按病历号查询
    Patient findByPatientId(String patientid,Integer a,Integer line);

    //按病人姓名查询
    Patient findByPatientName(String patientname,Integer a,Integer line);

    //出库帐页面显示
    List<Outku> findOutstorage(Integer a, Integer line);



    //个人信息
    //LogColumnName getRole(String role);
    int updateUserByid(String id,String tel,String address);
    int alterpassword(String userno,String password);
    //int adduser(String userno,String password,String username,String sex,Integer age,String IDnumber,String mobile,String address);
    int adduser(User tuser);
    int alteruser(User tuser);
    int deleteuser(User tuser);
    int updateLoging(String id);
    int updateLogingState(String id,String state);
    int deleteFromLog(String userno);
    String selectIDformLog(String num);








}
