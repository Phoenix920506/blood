package yuan.ding.service.Impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import yuan.ding.bean.*;
import yuan.ding.mapper.UserMapper;
import yuan.ding.service.UserService;

import javax.annotation.Resource;
import javax.persistence.criteria.CriteriaBuilder;
import java.util.Date;
import java.util.List;
import java.util.Map;

@Service
public class UserServiceImpl implements UserService {
    @Resource
    @Autowired

    private UserMapper userMapper;

    //登录
    public User getUserByuserno(String userno) {
        return userMapper.getUserByUserifno(userno);
    }

    //库存管理
    //按血型查询
    public Bloodinstorage findByBloType(String blotype,Integer page,Integer line) {
        Integer a = (page-1)*line;
        System.out.println("按血型" + blotype + "查询");
        Bloodinstorage bloType = userMapper.findByBloType(blotype,a,line);
        return bloType;
    }

    //按品种查询
    public Bloodinstorage findByBloKind(String blokind,Integer page,Integer line) {
        Integer a = (page-1)*line;
        System.out.println("按品种" + blokind + "查询");
        Bloodinstorage bloKind = userMapper.findByBloKind(blokind,a,line);
        return bloKind;
    }

    //库存管理页面查询
    public List<Kucun> findAllwarehouse(Integer page,Integer line){
        Integer a = (page-1)*line;
        System.out.println("库存管理显示");
        List<Kucun> findAllwarehouse = userMapper.findAllwarehouse(a,line);
        return findAllwarehouse;
    }

    //插入入库单
    public void insertKu(Inku inKu){
        Integer bloid = inKu.getBloid();
        String offeridnumber = inKu.getOfferidnumber();
        String offerbloman = inKu.getOfferbloman();
        String blotype = inKu.getBlotype();
        Integer blovolume  =inKu.getBlovolume();
        String blokind = inKu.getBlokind();
        String getbloman = inKu.getGetbloman();
        Date indate = inKu.getIndate();
        int warehouseId = inKu.getWarehouseId();
        System.out.println("impl");
        userMapper.insertKu(bloid,offeridnumber,offerbloman,blotype,blovolume,blokind,getbloman,indate,warehouseId);
    }

    //入库帐
    //按储血号查询
    public Bloodinstorage findByBloId(Integer bloid,Integer page,Integer line) {
        Integer a = (page-1)*line;
        System.out.println("按储血号" + bloid + "查询");
        Bloodinstorage bloId = userMapper.findByBloId(bloid,a,line);
        return bloId;
    }

    //按供血者姓名
    public Bloodinstorage findByOfferBloMan(String offerbloman,Integer page,Integer line) {
        Integer a = (page-1)*line;
        System.out.println("按供血者姓名" + offerbloman + "查询");
        Bloodinstorage offerBloman = userMapper.findByOfferBloMan(offerbloman,a,line);
        return offerBloman;
    }

    //入库帐页面显示
    public List<Inku> findInstorage(Integer page, Integer line){
        Integer a = (page-1)*line;
        System.out.println("入库帐页面显示");
        List<Inku> findInstorage = userMapper.findInstorage(a,line);
        return findInstorage;
    }

    //插入出库单
    public void insertoutKu(Outku outku){
        String patientid = outku.getPatientid();
        String patientname = outku.getPatientname();
        String blotype = outku.getBlotype();
        String blokind = outku.getBlokind();
        Integer transamount = outku.getTransamount();
        Date transdate  =outku.getTransdate();
        String getbloman = outku.getGetbloman();
        String postbloman = outku.getPostbloman();
        Integer pcount = userMapper.selectpcount(patientid,patientname);
        System.out.println(pcount);
        userMapper.outKu(blotype,blokind,transamount,transdate,getbloman,postbloman);

    }

    //出库帐
    //按病历号查询
    public Patient findByPatientId(String patientid,Integer page,Integer line) {
        Integer a = (page-1)*line;
        System.out.println("按病历号" + patientid + "查询");
        Patient patientId = userMapper.findByPatientId(patientid,a,line);
        return patientId;
    }

    //按病人姓名查询
    public Patient findByPatientName(String patientname,Integer page,Integer line) {
        Integer a = (page-1)*line;
        System.out.println("按病人姓名" + patientname + "查询");
        Patient patientName = userMapper.findByPatientName(patientname,a,line);
        return patientName;
    }

    //出库帐页面显示
    public List<Outku> findOutstorage(Integer page, Integer line){
        Integer a = (page-1)*line;
        System.out.println("出库帐页面显示");
        List<Outku> findOutstorage = userMapper.findOutstorage(a,line);
        return findOutstorage;
    }


    //个人信息
    @Override
    public int updateUserByid(String userno, String mobile, String address) {
//        System.out.println(id+tel+address);
        return userMapper.updateUserByid(userno,mobile,address);
    }
    @Override
    public  int alterpassword(String userno,String password){
        return userMapper.alterpassword(userno,password);
    }
    //    public  int adduser(String userno,String password,String username,String sex,Integer age,String IDnumber,String mobile,String address){
//        //return userMapper.adduser(userno,password,username,sex,age,IDnumber,mobile,address);
//        return userMapper.adduser()
//    }
    @Override
    public  int adduser(User tuser){
        //return userMapper.adduser(userno,password,username,sex,age,IDnumber,mobile,address);
        return userMapper.adduser(tuser);
    }
    @Override
    public int alteruser(User tuser){
        return userMapper.alteruser(tuser);
    }
    @Override
    public int deleteuser(User tuser){
        return userMapper.deleteuser(tuser);
    }

    @Override
    public int updateLoging(String id) {
        return userMapper.updateLogging(id);
    }
    //    @Override
//    public LogColumnName getRole(String  role) {
//        return userMapper.getRole(role);
//    }
    @Override
    public int updateLogingState(String id,String state){
        return  userMapper.updateLoggingState(id,state);
    }

    @Override
    public int deleteFromLog(String userno) {
        return userMapper.deleteFromLog(userno);
    }
    @Override
    public String selectIDformLog(String num){
        return userMapper.getUserLoggingId(num);
    }

}
