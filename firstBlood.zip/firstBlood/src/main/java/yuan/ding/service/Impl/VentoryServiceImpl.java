package yuan.ding.service.Impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import yuan.ding.bean.Bloodinventory;
import yuan.ding.bean.Ventory;
import yuan.ding.mapper.VentoryMapper;
import yuan.ding.service.VentoryService;

import javax.annotation.Resource;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

@Service
public class VentoryServiceImpl implements VentoryService {
    @Resource
    @Autowired
    private VentoryMapper ventoryMapper;
//    SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");//设置日期格式

    @Override
    public List<Ventory> selectVentoryByType(String bloType) {
//        Date nowdate = new Date();
//        String now = df.format(nowdate);
//        Calendar lastDate = Calendar.getInstance();
//        lastDate.add(Calendar.MONTH,-1);//减一个月
////        lastDate.set(Calendar.DATE, 1);//把日期设置为当月第一天
////        lastDate.roll(Calendar.DATE, -1);//日期回滚一天，也就是本月最后一天
//        String str=df.format(lastDate.getTime());
        return ventoryMapper.selectVentoryByType(bloType);
    }

    @Override
    public List<Ventory> selectVentoryByKind(String bloKind) {
        return ventoryMapper.selectVentoryByKind(bloKind);
    }

//    @Override
//    public List<Ventory> selectVentoryByDate(String indate) {
//        return ventoryMapper.selectVentoryByDate(indate);
//    }

    @Override
    public List<Ventory> selectVentory() {
        System.out.println("impl");
        return ventoryMapper.selectVentory();
    }
}
