package yuan.ding.service;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Service;
import yuan.ding.bean.Apply;
import yuan.ding.bean.UseBlood;

import java.util.Date;
import java.util.List;
import java.util.Map;

public interface UseBloodService {
    void insertPatient(Apply apply);

//    int selectoffice_id(String company,String county,String h_name);
//
//    void insertpatient(String patientID, String patientName, int office_id, String sex, Date birthday, int age, Date applyDate, Date bookDate, String diagnous, String goal, String history, String badHistory, String pregnancy, String  bloType, int transAmount, String bloKind, String patientResult);

    List<UseBlood> selectapplyBloodQuery();

    List<UseBlood> selectapplyBloodQueryByName(String patientname);

    List<UseBlood> selectapplyBloodQueryByID(String patientID);
}
