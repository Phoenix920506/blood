package yuan.ding.service;

import yuan.ding.bean.Bloodinventory;
import yuan.ding.bean.Ventory;

import java.util.List;

public interface VentoryService {
    List<Ventory> selectVentoryByType(String bloType);

    List<Ventory> selectVentoryByKind(String bloKind);

//    List<Ventory> selectVentoryByDate(String indate);

    List<Ventory> selectVentory();
}
