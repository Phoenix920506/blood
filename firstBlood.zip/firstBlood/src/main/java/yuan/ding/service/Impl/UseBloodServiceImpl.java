package yuan.ding.service.Impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Service;
import yuan.ding.bean.Apply;
import yuan.ding.bean.UseBlood;
import yuan.ding.mapper.UseBloodMapper;
import yuan.ding.service.UseBloodService;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;
import java.util.Map;

@Service
public class UseBloodServiceImpl implements UseBloodService {
    @Resource
    @Autowired
    private UseBloodMapper useBloodMapper;
//    @Override
//    public void insertpatient(String patientID, String patientName, int office_id, String sex, Date birthday, int age, Date applyDate, Date bookDate, String diagnous, String goal, String history, String badHistory, String pregnancy, String bloType, int transAmount, String bloKind, String patientResult) {
//        useBloodMapper.insertpatient(patientID,patientName,office_id,sex,birthday,age,applyDate,bookDate,diagnous,goal,history,badHistory,pregnancy,bloType,transAmount,bloKind,patientResult);
//    }

    @Override
    public void insertPatient(Apply apply) {
        String company = apply.getCompany();
        String county = apply.getCounty();
        String h_name = apply.getH_name();
        String patientID = apply.getPatientID();
        String patientName = apply.getPatientName();
        String sex = apply.getSex();
        Date birthday = apply.getBirthday();
        int age = apply.getAge();
        String p_tel = apply.getP_tel();
        Date applyDate = apply.getApplyDate();
        Date bookDate = apply.getBookDate();
        String diagnous = apply.getDiagnous();
        String goal = apply.getGoal();
        String history = apply.getHistory();
        String badHistory = apply.getBadHistory();
        String pregnancy = apply.getPregnancy();
        String  bloType = apply.getBloType();
        int transAmount = apply.getTransAmount();
        String bloKind =apply.getBloKind();
        String patientResult = apply.getPatientResult();
        int officeid = useBloodMapper.selectoffice_id(company,county,h_name);
        System.out.println(officeid);
        useBloodMapper.insertpatient(patientID, patientName, officeid, sex, birthday, age, p_tel, applyDate, bookDate, diagnous, goal, history, badHistory, pregnancy, bloType, transAmount, bloKind, patientResult);
    }
//
//    @Override
//    public int selectoffice_id(String company, String county, String h_name) {
//        return useBloodMapper.selectoffice_id(company,county,h_name);
//    }

    @Override
    public List<UseBlood> selectapplyBloodQuery() {
        return useBloodMapper.selectapplyBloodQuery();
    }

    @Override
    public List<UseBlood> selectapplyBloodQueryByName(String patientname){
        return useBloodMapper.selectapplyBloodQueryByName(patientname);
    }

    @Override
    public List<UseBlood> selectapplyBloodQueryByID(String patientID){
        return useBloodMapper.selectapplyBloodQueryByID(patientID);
    }
}
