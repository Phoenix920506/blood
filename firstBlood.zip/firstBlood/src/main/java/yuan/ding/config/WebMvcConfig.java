package yuan.ding.config;

import org.springframework.web.servlet.config.annotation.CorsRegistry;
import yuan.ding.common.DateConverter;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.format.FormatterRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Created by sang on 2018/1/2.
 */
@Configuration
public class WebMvcConfig implements WebMvcConfigurer {
    @Override
    public void addFormatters(FormatterRegistry registry) {
        registry.addConverter(new DateConverter());
    }

    @Bean
    public ExecutorService executorService() {
        return Executors.newCachedThreadPool();
    }

    @Override
    public void addCorsMappings(CorsRegistry registry){//跨域
        registry.addMapping("/**")
        .allowedOrigins("*")
                .allowCredentials(true)
                .allowedMethods("PUT","DELETE","POST","GET","PATCH")
//                .allowHeaders("header1","header2","header3")
//                .exposeHeaders("header1","header2")
                .allowCredentials(false).maxAge(3600)
                .allowCredentials(true);
    }

}
