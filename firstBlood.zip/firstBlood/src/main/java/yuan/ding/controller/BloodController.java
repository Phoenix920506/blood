package yuan.ding.controller;

import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.web.bind.annotation.*;
import yuan.ding.bean.*;
import yuan.ding.service.UserService;

import javax.annotation.Resource;
import javax.persistence.criteria.CriteriaBuilder;
import java.util.*;

@RestController
@ComponentScan(basePackages = "yuan.ding.service")
public class BloodController {
    @Resource
    @Autowired
    private UserService userService;

    //库存管理
    //按血型查询
    @RequestMapping(value = "/buser/inventoryQuery/blotype",method = {RequestMethod.POST,RequestMethod.GET})
    //@GetMapping("/buser/inventoryQuery/blotype")
    public  Bloodinstorage getBlotype(@Param("blotype") String blotype, @Param("a")Integer a,@Param("line") Integer line){
        Bloodinstorage bloType = userService.findByBloType(blotype,a,line);
        return bloType;
    }

    //按品种查询
    @GetMapping("/buser/inventoryQuery/blokind")
    public Bloodinstorage getBlokind(@Param("blokind") String blokind, @Param("a")Integer a,@Param("line") Integer line){
        System.out.println("aaa"+blokind);
        Bloodinstorage bloKind = userService.findByBloKind(blokind,a,line);
        return bloKind;
    }

    //库存管理页面查询
    @GetMapping("/buser/inventoryQuery")
    public  List<Kucun> getAllwarehouse(@Param("a")Integer a,@Param("line") Integer line){
        List<Kucun> findAllwarehouse = userService.findAllwarehouse(a,line);
        return findAllwarehouse;
    }

    //添加入库单
    @RequestMapping(value = "/buser/inBlood", method = {RequestMethod.POST})
    @ResponseBody
    public String inKu(@RequestBody Inku inku){
        userService.insertKu(inku);
        return "/buser/insertBlood";
    }

    //入库帐
    //按储血号查询
    @GetMapping("/buser/Inwarehouse/bloid")
    public Bloodinstorage getBloId(@Param("bloid") Integer bloid, @Param("a")Integer a,@Param("line") Integer line){
        Bloodinstorage bloId = userService.findByBloId(bloid,a,line);
        return bloId;
    }
    //按供血者姓名
    @GetMapping("/buser/Inwarehouse/offerbloman")
    public Bloodinstorage getOfferbloman(@Param("offerbloman") String offerbloman, @Param("a")Integer a,@Param("line") Integer line){
        Bloodinstorage offerBloman = userService.findByOfferBloMan(offerbloman,a,line);
        return offerBloman;
    }

    //入库帐页面显示
    @GetMapping("/buser/Inwarehouse")
    public  List<Inku> getInwarehouse(@Param("a")Integer a, @Param("line") Integer line){
        List<Inku> getInwarehouse = userService.findInstorage(a,line);
        return getInwarehouse;
    }

    //添加出库单
    @RequestMapping(value = "/buser/outBlood", method = {RequestMethod.POST,RequestMethod.GET})
    @ResponseBody
    public String outKu(@RequestBody Outku outku){
        userService.insertoutKu(outku);
        return "/buser/outBlood";
    }

    //出库帐
    //按病历号查询
    @GetMapping("/buser/outBlood")
    public Patient getPatientid(@Param("patientid") String patientid, @Param("a")Integer a,@Param("line") Integer line){
        Patient patientId = userService.findByPatientId(patientid,a,line);
        return patientId;
    }

    //按病人姓名查询
    @GetMapping("/buser/outBlood/patientname")
    public  Patient getPatientname(@Param("patientname") String patientname, @Param("a")Integer a,@Param("line") Integer line){
        Patient patientName = userService.findByPatientName(patientname,a,line);
        return patientName;
    }

    //出库帐页面显示
    @GetMapping("/buser/Outwarehouse")
    public  List<Outku> getOutwarehouse(@Param("a")Integer a, @Param("line") Integer line){
        List<Outku> getOutwarehouse = userService.findOutstorage(a,line);
        return getOutwarehouse;
    }

}
