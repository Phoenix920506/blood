package yuan.ding.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.web.bind.annotation.*;
import yuan.ding.bean.Apply;
import yuan.ding.bean.UseBlood;
import yuan.ding.mapper.UseBloodMapper;
import yuan.ding.service.UseBloodService;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;
import java.util.Map;

@RestController
@ComponentScan(basePackages = "yuan.ding.service")
public class UseBloodController {
    @Resource
    @Autowired
    private UseBloodService useBloodService;

    //插入用血申请单
    @RequestMapping(value = "/buser/applyBlood", method = {RequestMethod.POST})
    @ResponseBody
    public String applyBlood(@RequestBody Apply apply){
//        for (Map.Entry<String, Object> entry : map.entrySet()) {
//            System.out.println("Key = " + entry.getKey() + ", Value = " + entry.getValue());
//
//        }
        useBloodService.insertPatient(apply);
        return "/buser/applyBlood";
    }
    //查询用血情况表
    @RequestMapping(value = "/buser/applyBloodQuery",method = {RequestMethod.POST,RequestMethod.GET})
//    @GetMapping("/selectapplyBloodQuery")
    @ResponseBody
    public List<UseBlood> applyBloodQuery(//@RequestParam(value = "id") int id,
                                @RequestParam(value = "patientname") String patientname,
                                @RequestParam(value = "patientID") String patientID){
        List<UseBlood> list;
        if(!patientname.isEmpty() && patientID.isEmpty()){
            System.out.println("aaa");
            list = useBloodService.selectapplyBloodQueryByName(patientname);
        }else if (!patientID.isEmpty() && patientname.isEmpty()){
            System.out.println("bbb");
            list = useBloodService.selectapplyBloodQueryByID(patientID);
        }else {
            System.out.println("ccc");
            list = useBloodService.selectapplyBloodQuery();
        }
        return list;
    }

    //提交用血情况表
    @RequestMapping(value = "/buser/postBloodQuery",method = {RequestMethod.POST,RequestMethod.GET})
//    @GetMapping("/selectapplyBloodQuery")
    @ResponseBody
    public List<UseBlood> postBloodQuery(){
        List<UseBlood> list;
        System.out.println("ccc");
        list = useBloodService.selectapplyBloodQuery();
        return list;
    }

}
