package yuan.ding.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.web.bind.annotation.*;
import yuan.ding.bean.Bloodinventory;
import yuan.ding.bean.Ventory;
import yuan.ding.service.VentoryService;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;

@RestController
@ComponentScan(basePackages = "yuan.ding.service")
public class VentoryController {
    @Resource
    @Autowired
    private VentoryService ventoryService;

    @RequestMapping(value = "/buser/ventory", method = {RequestMethod.POST,RequestMethod.GET})
    @ResponseBody
    public List<Ventory> ventory(@RequestParam(value = "bloType") String bloType,
                                        @RequestParam(value = "bloKind") String bloKind){
        List<Ventory> list;
        if(!bloType.isEmpty() && bloKind.isEmpty()){
            System.out.println("aaa");
            list = ventoryService.selectVentoryByType(bloType);
        }else if (bloType.isEmpty() && !bloKind.isEmpty()){
            System.out.println("bbb");
            list = ventoryService.selectVentoryByKind(bloKind);
//        }else if (bloType.isEmpty() && bloKind.isEmpty() && !indate.isEmpty()){
//            System.out.println("ddd");
//            list = ventoryService.selectVentoryByDate(indate);
        }else {
            System.out.println("ccc");
            list = ventoryService.selectVentory();
        }
        return list;
    }
}
