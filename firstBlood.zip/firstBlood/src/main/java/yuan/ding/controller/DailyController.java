package yuan.ding.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.web.bind.annotation.*;
import yuan.ding.bean.Dailyrecord;
import yuan.ding.bean.InsertDaily;
import yuan.ding.service.DailyService;

import javax.annotation.Resource;
import java.util.List;

@RestController
@ComponentScan(basePackages = "yuan.ding.service")
public class DailyController {
    @Resource
    @Autowired
    private DailyService dailyService;

    @RequestMapping(value = "/admin/daily",method = {RequestMethod.GET})
    @ResponseBody
    public List<Dailyrecord> selectAllDaily(){
        return dailyService.selectAllDaily();
    }

    @RequestMapping(value = "/admin/daily/insertDaily",method = {RequestMethod.POST})
    @ResponseBody
    public void insertDaily(@RequestBody InsertDaily insertDaily){
        System.out.println("InsertDaily");
        dailyService.insertdaily(insertDaily);
    }

}
