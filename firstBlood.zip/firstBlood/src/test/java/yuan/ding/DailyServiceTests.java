package yuan.ding;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import yuan.ding.bean.Dailyrecord;
import yuan.ding.bean.InsertDaily;
import yuan.ding.service.DailyService;

import java.util.Date;
import java.util.List;

@RunWith(SpringRunner.class)
@SpringBootTest
public class DailyServiceTests {
    @Autowired
    DailyService dailyService;

    @Test
    public void selectAllDaily() {
        List<Dailyrecord> dailyrecords = dailyService.selectAllDaily();
        System.out.println(dailyrecords);
    }

    @Test
    public void insertdaily() {
        InsertDaily insertDaily = new InsertDaily();
        insertDaily.setDailyDate(new Date());
        insertDaily.setDailyName("呵呵");
        insertDaily.setDailyPerformance("aaa");
        insertDaily.setDailyPhonenumber("bbb");
        insertDaily.setExceptioncheck("exceptoin");
        insertDaily.setDailyRecord("ccc");
        dailyService.insertdaily(insertDaily);
    }



}
