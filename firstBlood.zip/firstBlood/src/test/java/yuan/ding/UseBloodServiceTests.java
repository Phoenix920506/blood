package yuan.ding;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import yuan.ding.bean.Apply;
import yuan.ding.bean.UseBlood;
import yuan.ding.service.Impl.UseBloodServiceImpl;

import java.util.Date;
import java.util.List;

@RunWith(SpringRunner.class)
@SpringBootTest
public class UseBloodServiceTests {

    @Autowired
    UseBloodServiceImpl useBloodService;

    @Test
    public void insertPatient() {

        Apply apply = new Apply("四川省人民医院","四川省成都市青羊区","血液科","201905160001","悟空","male",new Date(),90,"13452627384",new Date(),new Date(),"cc","aaa","no","cc","no","O",19,"全血","good");

        useBloodService.insertPatient(apply);
    }

    @Test
    public void selectapplyBloodQuery() {
        List<UseBlood> list = useBloodService.selectapplyBloodQuery();
        System.out.println(list);
    }

    @Test
    public void selectByname(){
        List<UseBlood> list1 = useBloodService.selectapplyBloodQueryByName("李明");
        System.out.println(list1);
    }

    @Test
    public void selectByid(){
        List<UseBlood> list2 = useBloodService.selectapplyBloodQueryByID("201505101234");
        System.out.println(list2);
    }


}
