package yuan.ding;

import org.junit.Test;
import org.junit.experimental.theories.ParameterSignature;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import yuan.ding.bean.*;
import yuan.ding.service.Impl.UserServiceImpl;

import java.util.Date;
import java.util.List;

@RunWith(SpringRunner.class)
@SpringBootTest
public class UserServiceTests {

    @Autowired
    UserServiceImpl userService;

    @Test
    public void selectByblotype(){
        Bloodinstorage select = userService.findByBloType("AB",1,1);
        System.out.println(select);
    }

    @Test
    public void selectByblokind(){
        Bloodinstorage select1 = userService.findByBloKind("浓缩血小板",1,1);
        System.out.println(select1);
    }

    @Test
    public void selectAllkucun(){
        List<Kucun> list1 = userService.findAllwarehouse(1,1);
        System.out.println(list1);
    }

    @Test
    public void insertku(){
        Inku in = new Inku("123","lili","AB",2000,"浓缩血小板","赵四",new Date(),1);
        userService.insertKu(in);
    }

    @Test
    public void selectBybloid(){
        Bloodinstorage select2 = userService.findByBloId(1,1,1);
        System.out.println(select2);
    }

    @Test
    public void selectBybloman(){
        Bloodinstorage select3 = userService.findByOfferBloMan("刘能",1,1);
        System.out.println(select3);
    }

    @Test
    public void selectAllinku(){
        List<Inku> list2 = userService.findInstorage(1,1);
        System.out.println(list2);
    }

    @Test
    public void selectBypatientid(){
        Patient select4 = userService.findByPatientId("201505101234",1,1);
        System.out.println(select4);
    }

    @Test
    public void selectBypatientname(){
        Patient select5 = userService.findByPatientName("李明",1,1);
        System.out.println(select5);
    }

    @Test
    public void selectAlloutku(){
        List<Outku> list3 = userService.findOutstorage(1,1);
        System.out.println(list3);
    }

    @Test
    public void updateuserbyid(){
        String u = "A005";
        String m = "12345678901";
        String a = "chengdu";
        userService.updateUserByid(u,m,a);
    }
}
