package com.two.service;

import com.two.entity.Bloodinstorage;
import com.two.entity.Patient;
import com.two.entity.Tuser;
import com.two.entity.Warehouse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.two.mapper.UserMapper;

import java.util.List;
import java.util.Vector;

@Service
public class UserService {
    @Autowired
    private UserMapper userMapper;

    public Vector<Tuser> findAllUser() {
        return userMapper.findAllUser();
    }

    public String isPwd(){
        return userMapper.isPwd();
    }

    //库存管理
    //按血型查询
    public Bloodinstorage findByBloType(String blotype){
        System.out.println("按血型"+blotype+"查询");
        Bloodinstorage bloType = userMapper.findByBloType(blotype);
        return bloType;
    }

    //按品种查询
    public Bloodinstorage findByBloKind(String blokind) {
        System.out.println("按品种"+blokind+"查询");
        Bloodinstorage bloKind = userMapper.findByBloKind(blokind);
        return bloKind;
    }

    //入库帐
    //按储血号查询
    public Bloodinstorage findByBloId(Integer bloid) {
        System.out.println("按储血号"+bloid+"查询");
        Bloodinstorage bloId = userMapper.findByBloId(bloid);
        return bloId;
    }

    //按供血者姓名
    public Bloodinstorage findByOfferBloMan(String offerbloman){
        System.out.println("按供血者姓名"+offerbloman+"查询");
        Bloodinstorage offerBloman = userMapper.findByOfferBloMan(offerbloman);
        return offerBloman;
    }

    //出库帐
    //按病历号查询
    public Patient findByPatientId(Integer patientid){
        System.out.println("按病历号"+patientid+"查询");
        Patient patientId = userMapper.findByPatientId(patientid);
        return patientId;
    }

    //按病人姓名查询
    public Patient findByPatientName(String patientname){
        System.out.println("按病人姓名"+patientname+"查询");
        Patient patientName = userMapper.findByPatientName(patientname);
        return patientName;
    }

    //按warehouseid查
    public Warehouse findByWarehouseId(Integer warehouseid){
        System.out.println("按warehouse"+warehouseid+"查");
        Warehouse warehouseId = userMapper.findByWarehouseId(warehouseid);
        return warehouseId;
    }



}
