package com.two.controller;

import com.two.entity.Bloodinstorage;
import com.two.entity.Patient;
import com.two.entity.Warehouse;
import com.two.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;



@RestController
public class TestGetDataController {


    @Autowired
    private UserService userService;

    //@RequestMapping(value = "/login", method = {RequestMethod.POST, RequestMethod.GET})

    //库存管理
    //按血型查询
    @GetMapping("/user/inventoryQuery/{blotype}")
    public  Bloodinstorage getBlotype(@PathVariable("blotype") String blotype){
        Bloodinstorage bloType = userService.findByBloType(blotype);
        return bloType;
    }

    //按品种查询
    @GetMapping("/user/inventoryQuery/{blokind}")
    public Bloodinstorage getBlokind(@PathVariable("blokind") String blokind){
        Bloodinstorage bloKind = userService.findByBloKind(blokind);
        return bloKind;
    }

    //入库帐
    //按储血号查询
    @GetMapping("/user/inBlood/{bloid}")
    public Bloodinstorage getBloId(@PathVariable("bloid") Integer bloid){
        Bloodinstorage bloId = userService.findByBloId(bloid);
        return bloId;
    }
    //按供血者姓名
    @GetMapping("/user/inBlood/{offerbloman}")
    public Bloodinstorage getOfferbloman(@PathVariable("offerbloman") String offerbloman){
        Bloodinstorage offerBloman = userService.findByOfferBloMan(offerbloman);
        return offerBloman;
    }

    //出库帐
    //按病历号查询
    @GetMapping("/user/outBlood/{patientid}")
    public Patient getPatientid(@PathVariable("patientid") Integer patientid){
        Patient patientId = userService.findByPatientId(patientid);
        return patientId;
    }

    //按病人姓名查询
    @GetMapping("/user/outBlood/{patientname}")
    public  Patient getPatientname(@PathVariable("patientname") String patientname){
        Patient patientName = userService.findByPatientName(patientname);
        return patientName;
    }

    //按warehouseid查
    @GetMapping("/user/warehouse/(warehouseid}")
    public Warehouse getWarehouseid(@PathVariable("warehouseid") Integer warehouseid){
        Warehouse warehouseId = userService.findByWarehouseId(warehouseid);
        return warehouseId;
    }

}
