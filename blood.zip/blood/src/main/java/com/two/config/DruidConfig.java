package com.two.config;

import com.alibaba.druid.pool.DruidDataSource;
import com.alibaba.druid.support.http.StatViewServlet;
import com.alibaba.druid.support.http.WebStatFilter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.boot.web.servlet.ServletRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.sql.DataSource;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

@Configuration
public class DruidConfig {

    //配置自定义数据源,将自己定义的配置和DruidDataSource类中的属性相映射
    @ConfigurationProperties(prefix = "spring.datasource")
    @Bean
    public DataSource druid(){
        return new DruidDataSource();
    }

    //配置Druid的监控
    //1-配置一个管理后台的servlet
    //因为servlet是内置的，没有XML文件，所以以下面方式配置

    //使用 Druid 数据库连接池的项目改为 Spring boot 项目时，还需保留 Druid 对 SQL 方面的监控。那么就迫切的需要 Spring boot 支持 Servlet 功能。
    @Bean
    public ServletRegistrationBean statViewServlet(){
        ServletRegistrationBean bean = new ServletRegistrationBean(new StatViewServlet(),"/druid/*");
        Map<String,String> initParams = new HashMap<>();

        initParams.put("loginUsername","admin");
        initParams.put("loginPassword","123456");

        //设置白名单，默认允许所有访问
        initParams.put("allow","");
        // 设置黑名单
        initParams.put("deny","47.106.153.21");
//        initParams.put("deny","127.0.0.1");

        bean.setInitParameters(initParams);
        return bean;
    }
    //2-配置一个web监控的filter--拦截器
    /**
     * 配置 Druid 监控 之  web 监控的 filter
     * WebStatFilter：用于配置Web和Druid数据源之间的管理关联监控统计
     * 这个过滤器的作用就是统计 web 应用请求中所有的数据库信息，
     * 比如 发出的 sql 语句，sql 执行的时间、请求次数、请求的 url 地址、以及seesion 监控、数据库表的访问次数 等等。
     */
    @Bean
    public FilterRegistrationBean webStatFilter(){
        FilterRegistrationBean bean = new FilterRegistrationBean();
        bean.setFilter(new WebStatFilter());

        Map<String,String> initParams = new HashMap<>();
        initParams.put("exclusions","*.js,*.css,/druid/*");

        bean.setInitParameters(initParams);
        //拦截所有请求
        bean.setUrlPatterns(Arrays.asList("/*"));

        return bean;
    }
}
