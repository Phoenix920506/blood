package com.two.mapper;

import com.two.entity.Bloodinstorage;
import com.two.entity.Patient;
import com.two.entity.Tuser;
import com.two.entity.Warehouse;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Component;

import java.util.Vector;

@Mapper
@Component
public interface UserMapper {
    //全部用户查询
    @Select("select * from tuser")
    Vector<Tuser> findAllUser();

    //登录密码判断
    @Select("select password from tuser where userno='A001'")
    String isPwd();

    //库存管理
    //按血型查询
    @Select("select * from bloodinstorage where bloType=#{blotype}")
    public Bloodinstorage findByBloType(@Param("bloType") String blotype);

    //按品种查询
    @Select("select * from bloodinstorage and bloodinventory where bloodinstorage.blotype = bloodinventory.blotype bloKind=#{blokind}")
    public Bloodinstorage findByBloKind(@Param("bloKind") String blokind);

    //库存管理页面查询 入库日期 血型 品种instorage 库存量inventory   采血人instorage     温度             存放位置 warehouse 有效日期   供血者编号instorage
    //@Select("select inDate,bloodinstorage.bloType,bloodinstorage.bloKind,capacity,getBloman,warehouse_temper,warehouse_number,cabinet_number,layer_number,effectiveDate,offerIDnumber from bloodinstorage,bloodinventory,warehouse where bloodinstorage.bloType = bloodinventory.bloType and bloodinventory.warehouse_id = warehouse.warehouse_id")
    //public Bloodinstorage findAllwarehouse

    //入库帐
    //按储血号查询
    @Select("select * from bloodinstorage where bloId=#{bloid}")
    public Bloodinstorage findByBloId(@Param("bloId") Integer bloid);

    //按供血者姓名
    @Select("select * from bloodinstorage where offerBloman=#{offerbloman}")
    public Bloodinstorage findByOfferBloMan(@Param("offerBloman") String offerbloman);

    //出库帐
    //按病历号查询
    @Select("select * from patient where patientId=#{patientid}")
    public Patient findByPatientId(@Param("patientID") Integer patientid);

    //按病人姓名查询
    @Select("select * from patientname where patientname=#{patientname}")
    public Patient findByPatientName(@Param("patientName") String patientname);

    //按warehouseid查
    @Select("select * from warehouse where warehouseid=#{warehouse_id}")
    public Warehouse findByWarehouseId(@Param("warehouseId") Integer warehouseId);
}
