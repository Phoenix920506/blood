package com.two;

import com.two.entity.Warehouse;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

import java.util.ArrayList;
import java.util.List;

@SpringBootApplication
@ComponentScan(basePackages = "com.two.mapper")
public class BloodDemoApplication {

    public static void main(String[] args) {
        SpringApplication.run(BloodDemoApplication.class, args);

    }
}
