package com.two.entity;

import java.util.Date;

public class Dailyrecord {
    private Integer logId;

    private Date logDate;

    private String logName;

    private Integer logPhonenumber;

    private String logPerformance;

    private String exceptioncheck;

    private String logRecord;

    public Integer getLogId() {
        return logId;
    }

    public void setLogId(Integer logId) {
        this.logId = logId;
    }

    public Date getLogDate() {
        return logDate;
    }

    public void setLogDate(Date logDate) {
        this.logDate = logDate;
    }

    public String getLogName() {
        return logName;
    }

    public void setLogName(String logName) {
        this.logName = logName == null ? null : logName.trim();
    }

    public Integer getLogPhonenumber() {
        return logPhonenumber;
    }

    public void setLogPhonenumber(Integer logPhonenumber) {
        this.logPhonenumber = logPhonenumber;
    }

    public String getLogPerformance() {
        return logPerformance;
    }

    public void setLogPerformance(String logPerformance) {
        this.logPerformance = logPerformance == null ? null : logPerformance.trim();
    }

    public String getExceptioncheck() {
        return exceptioncheck;
    }

    public void setExceptioncheck(String exceptioncheck) {
        this.exceptioncheck = exceptioncheck == null ? null : exceptioncheck.trim();
    }

    public String getLogRecord() {
        return logRecord;
    }

    public void setLogRecord(String logRecord) {
        this.logRecord = logRecord == null ? null : logRecord.trim();
    }
}