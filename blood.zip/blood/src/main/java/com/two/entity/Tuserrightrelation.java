package com.two.entity;

public class Tuserrightrelation {
    private Long turId;

    private String userno;

    private Long trId;

    private Integer rightType;

    public Long getTurId() {
        return turId;
    }

    public void setTurId(Long turId) {
        this.turId = turId;
    }

    public String getUserno() {
        return userno;
    }

    public void setUserno(String userno) {
        this.userno = userno == null ? null : userno.trim();
    }

    public Long getTrId() {
        return trId;
    }

    public void setTrId(Long trId) {
        this.trId = trId;
    }

    public Integer getRightType() {
        return rightType;
    }

    public void setRightType(Integer rightType) {
        this.rightType = rightType;
    }
}