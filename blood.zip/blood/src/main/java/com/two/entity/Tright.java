package com.two.entity;

public class Tright {
    private Long trId;

    private Long parentTrId;

    private String rightName;

    private String description;

    public Long getTrId() {
        return trId;
    }

    public void setTrId(Long trId) {
        this.trId = trId;
    }

    public Long getParentTrId() {
        return parentTrId;
    }

    public void setParentTrId(Long parentTrId) {
        this.parentTrId = parentTrId;
    }

    public String getRightName() {
        return rightName;
    }

    public void setRightName(String rightName) {
        this.rightName = rightName == null ? null : rightName.trim();
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description == null ? null : description.trim();
    }
}