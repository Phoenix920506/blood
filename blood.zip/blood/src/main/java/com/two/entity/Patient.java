package com.two.entity;

import java.util.Date;

public class Patient {
    private Integer pCount;

    private Integer patientid;//病历号

    private String patientname;

    private Integer officeId;

    private String sex;

    private Date birthday;

    private Integer age;

    private Date applydate;

    private Date bookdate;

    private String diagnous;

    private String goal;

    private String history;

    private String badhistory;

    private String pregnancy;

    private String blotype;

    private Integer transamount;

    private String blokind;

    private String patientresult;

    public Integer getpCount() {
        return pCount;
    }

    public void setpCount(Integer pCount) {
        this.pCount = pCount;
    }

    public Integer getPatientid() {
        return patientid;
    }

    public void setPatientid(Integer patientid) {
        this.patientid = patientid;
    }

    public String getPatientname() {
        return patientname;
    }

    public void setPatientname(String patientname) {
        this.patientname = patientname == null ? null : patientname.trim();
    }

    public Integer getOfficeId() {
        return officeId;
    }

    public void setOfficeId(Integer officeId) {
        this.officeId = officeId;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex == null ? null : sex.trim();
    }

    public Date getBirthday() {
        return birthday;
    }

    public void setBirthday(Date birthday) {
        this.birthday = birthday;
    }

    public Integer getAge() {
        return age;
    }

    public void setAge(Integer age) {
        this.age = age;
    }

    public Date getapplydate() {
        return applydate;
    }

    public void setapplydate(Date applydate) {
        this.applydate = applydate;
    }

    public Date getbookdate() {
        return bookdate;
    }

    public void setbookdate(Date bookdate) {
        this.bookdate = bookdate;
    }

    public String getDiagnous() {
        return diagnous;
    }

    public void setDiagnous(String diagnous) {
        this.diagnous = diagnous == null ? null : diagnous.trim();
    }

    public String getGoal() {
        return goal;
    }

    public void setGoal(String goal) {
        this.goal = goal == null ? null : goal.trim();
    }

    public String getHistory() {
        return history;
    }

    public void setHistory(String history) {
        this.history = history == null ? null : history.trim();
    }

    public String getBadhistory() {
        return badhistory;
    }

    public void setBadhistory(String badhistory) {
        this.badhistory = badhistory == null ? null : badhistory.trim();
    }

    public String getPregnancy() {
        return pregnancy;
    }

    public void setPregnancy(String pregnancy) {
        this.pregnancy = pregnancy == null ? null : pregnancy.trim();
    }

    public String getBlotype() {
        return blotype;
    }

    public void setBlotype(String blotype) {
        this.blotype = blotype == null ? null : blotype.trim();
    }

    public Integer getTransamount() {
        return transamount;
    }

    public void setTransamount(Integer transamount) {
        this.transamount = transamount;
    }

    public String getBlokind() {
        return blokind;
    }

    public void setBlokind(String blokind) {
        this.blokind = blokind == null ? null : blokind.trim();
    }

    public String getPatientresult() {
        return patientresult;
    }

    public void setPatientresult(String patientresult) {
        this.patientresult = patientresult == null ? null : patientresult.trim();
    }
}