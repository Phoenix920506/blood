package com.two.entity;

import java.util.Date;

public class Bloodoutstorage {
    private Integer blooutId;

    private Integer pCount;

    private String blotype;

    private String blokind;

    private Integer transamount;

    private Date transdate;

    private String getbloman;

    private String postbloman;

    public Integer getBlooutId() {
        return blooutId;
    }

    public void setBlooutId(Integer blooutId) {
        this.blooutId = blooutId;
    }

    public Integer getpCount() {
        return pCount;
    }

    public void setpCount(Integer pCount) {
        this.pCount = pCount;
    }

    public String getBlotype() {
        return blotype;
    }

    public void setBlotype(String blotype) {
        this.blotype = blotype == null ? null : blotype.trim();
    }

    public String getBlokind() {
        return blokind;
    }

    public void setBlokind(String blokind) {
        this.blokind = blokind == null ? null : blokind.trim();
    }

    public Integer getTransamount() {
        return transamount;
    }

    public void setTransamount(Integer transamount) {
        this.transamount = transamount;
    }

    public Date getTransdate() {
        return transdate;
    }

    public void setTransdate(Date transdate) {
        this.transdate = transdate;
    }

    public String getGetbloman() {
        return getbloman;
    }

    public void setGetbloman(String getbloman) {
        this.getbloman = getbloman == null ? null : getbloman.trim();
    }

    public String getPostbloman() {
        return postbloman;
    }

    public void setPostbloman(String postbloman) {
        this.postbloman = postbloman == null ? null : postbloman.trim();
    }
}