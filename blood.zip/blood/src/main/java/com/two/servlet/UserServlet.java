package com.two.servlet;

import javax.servlet.annotation.WebServlet;

@WebServlet("/UserServlet")
public class UserServlet {

}
